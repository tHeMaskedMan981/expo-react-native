import React from 'react';
import { View } from 'react-native';
import {
  RkTabSet,
  RkTab,
  RkStyleSheet,
} from 'react-native-ui-kitten';
import { TabContentScreen } from './TabContentScreen';

export class IconTabScreen extends React.Component {
  static navigationOptions = {
    title: 'Icon Tabs',
  };

  render() {
    return (
      <View style={styles.container}>
        <RkTabSet style={styles.container}>
          <RkTab
            title='Calls'
            icon={require('../../img/icons/phone.png')}>
            <TabContentScreen style={styles.tabContent1} />
          </RkTab>
          <RkTab
            title='Contacts'
            icon={require('../../img/icons/user.png')}>
            <TabContentScreen style={styles.tabContent2} />
          </RkTab>
          <RkTab
            title='Favorites'
            icon={require('../../img/icons/heart.png')}
            isSelected={true}>
            <TabContentScreen
              style={styles.tabContent3}
              message='Tab 2 loves React Native UI Kitten'
            />
          </RkTab>
        </RkTabSet>
      </View>
    );
  }
}

const styles = RkStyleSheet.create(theme => ({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  tabContent1: {
    backgroundColor: 'red',
  },
  tabContent2: {
    backgroundColor: 'green',
  },
  tabContent3: {
    backgroundColor: 'blue',
  },
}));
